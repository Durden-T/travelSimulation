#ifndef TIME_H
#define TIME_H



#include"common.h"

//ʱ�䣺��0��Ϊ���� �ڶ��� �ڶ��� ������......
//ʱ�� 0-23 time unsigned int
class Time
{
	friend istream& operator>>(istream& is, Time& time);
	friend ostream& operator<<(ostream& os, const Time& time);
	friend bool operator>(const Time& lhs, const Time& rhs);
	friend bool operator<=(const Time& lhs, const Time& rhs);

public:
	Time(unsigned int _day = INT_MAX, unsigned int _hour = INT_MAX, unsigned int _minute = INT_MAX) :day(_day), hour(_hour), minute(_minute) {}//Ĭ�ϳ�ʼ��Ϊ�����ʱ�䣬��������ط��Ĳ���

	bool valid();//���ʱ���Ƿ���Ч

	Time& advanceTo(const Time& after);//�ϲ������˳�/�ɻ���ʱ��ǰ������һ��

private:
	unsigned int day, hour, minute;
};

inline bool Time::valid()
{
	return hour < 24 && minute < 60;
}

inline istream& operator>>(istream& is, Time& time)
{
	return (is >> time.day >> time.hour >> time.minute);
}

inline ostream& operator<<(ostream& os, const Time& time)
{
	return (os << "��" << time.day << "��" << time.hour << "ʱ" << time.minute << "��");
}

inline bool operator<=(const Time& lhs, const Time& rhs)
{
	return !(lhs > rhs);
}

inline bool operator>(const Time& lhs, const Time& rhs)
{
	if (lhs.day > rhs.day)
		return true;
	if (lhs.day < rhs.day)
		return false;
	if (lhs.hour > rhs.hour)
		return true;
	if (lhs.hour < rhs.hour)
		return false;
	if (lhs.minute > rhs.minute)
		return true;
	else
		return false;
}

inline Time& Time::advanceTo(const Time& after)
{
	if (after.day)
		day += after.day;
	else if (hour > after.hour || hour == after.hour && minute > after.minute)
		++day;
	hour = after.hour;
	minute = after.minute;
	return *this;
}



#endif